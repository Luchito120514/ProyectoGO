# Para iniciar el programa se tiene que instalar la extension Live Server, luego de eso se tiene que ingresar a la carpeta "api" y hacer correr el main.go
# Luego de eso dar click derecho en la parte que dice "html" y seleccionar "Abrir con live Server"
# Y por ultimo ya esperar a que el programa corra en el buscador :3